# FoldQuantVLA brand kit

This package contains the exact logo, Inter webfonts, and method diagram used by the FoldQuantVLA project page.

## Contents

- `logo/foldquantvla-mark.svg`: standalone folding-matrix mark.
- `logo/foldquantvla-wordmark.svg`: ready-to-use mark and FoldQuantVLA lockup.
- `fonts/Inter-{400,500,600,700,800}.woff`: locally hosted Inter weights.
- `fonts/OFL.txt`: required SIL Open Font License.
- `css/foldquantvla-brand.css`: font declarations and reusable brand styles.
- `diagrams/foldquantvla-method.svg`: full desktop method diagram.
- `diagrams/foldquantvla-method-mobile.svg`: responsive mobile method diagram.

## Recommended web markup

```html
<link rel="stylesheet" href="assets/foldquantvla-brand.css">

<a class="foldquantvla-brand" href="/">
  <img src="assets/foldquantvla-mark.svg" width="33" height="33" alt="">
  <span>FoldQuantVLA</span>
</a>
```

Keep the logo red `#ED1C24`, wordmark ink `#17201C`, and the 10 px gap defined in the CSS. The wordmark uses Inter 700 with slightly tightened letter spacing.

For the method diagram, use the mobile SVG below 700 px:

```html
<picture>
  <source media="(max-width: 700px)" srcset="assets/foldquantvla-method-mobile.svg">
  <img src="assets/foldquantvla-method.svg" alt="FoldQuantVLA method overview">
</picture>
```
